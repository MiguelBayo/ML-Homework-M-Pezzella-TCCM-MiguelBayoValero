import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.kernel_ridge import KernelRidge
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error

# Load the partition function data. Change the path to where you have the file saved in your computer
pf_file = r'C:\Users\Usuario\Desktop\UAM\M2\Machine Learning\HOMEWORKS\pythonProject\12C2__8states.pf.txt'
columns_pf = ["Index", "PFunction"]
pf_data = pd.read_csv(pf_file, sep=r"\s+", names=columns_pf, skiprows=1, engine='python')
print(pf_data)

# Prepare the data

X_pf = pf_data["Index"].values.reshape(-1, 1)
y_pf = pf_data["PFunction"].values

# Split the data into training and testing sets
X_train_pf, X_test_pf, y_train_pf, y_test_pf = train_test_split(X_pf, y_pf, test_size=0.2, random_state=42)

# Define Kernel Ridge Regression models
krr_pf = KernelRidge(kernel="rbf", alpha=1e-2, gamma=1e-2)  # Partition function

# Train the models
krr_pf.fit(X_train_pf, y_train_pf)

# Predict heat capacity and partition function
y_pred_pf = krr_pf.predict(X_test_pf)

# Evaluate the models

mse_pf = mean_squared_error(y_test_pf, y_pred_pf)
r2_pf = r2_score(y_test_pf, y_pred_pf)
mae_pf = mean_absolute_error(y_test_pf, y_pred_pf)
print(f"Partition Function - MSE: {mse_pf:.6f}, R²: {r2_pf:.6f}, MAE: {mae_pf:.6f}, RMSE:{np.sqrt(mse_pf):.6f}")

# Generate smooth predictions for visualization
X_smooth = np.linspace(X_pf.min(), X_pf.max(), 500).reshape(-1, 1)
y_smooth_pf = krr_pf.predict(X_smooth)


# Plot results for partition function
plt.figure(figsize=(10, 6))
plt.plot(X_pf, y_pf, "g.", markersize=8, label="Partition Function Data")
plt.plot(X_smooth, y_smooth_pf, "b-", label="Partition Function Prediction")
plt.xlabel("Index", fontsize=16)
plt.ylabel("Partition Function", fontsize=16)
plt.title("Kernel Ridge Regression - Partition Function", fontsize=16)
plt.legend()
plt.grid()
plt.show()
