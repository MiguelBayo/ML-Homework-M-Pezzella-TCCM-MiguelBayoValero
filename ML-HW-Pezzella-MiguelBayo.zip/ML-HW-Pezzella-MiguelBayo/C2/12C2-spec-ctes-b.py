import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestRegressor
from sklearn.linear_model import LinearRegression
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error
import matplotlib.pyplot as plt
from sklearn.preprocessing import PolynomialFeatures

# Change the path to the path where "12C2__8states.states" is located on your computer
file_path_C12 = r'C:\Users\Usuario\Desktop\UAM\M2\Machine Learning\HOMEWORKS\pythonProject\12C2__8states.states'


# Load the dataset
# Adjust column names and separator based on the file structure
columns = ["Index", "Energy", "gtot", "J", "Unc", "tau", "g", "+/-", "ef", "State", "v", "L", "S", "O", "Fsym", "id", "src", "Ecalc"]
C12 = pd.read_csv(file_path_C12, names=columns, sep=r"\s+", skiprows=1, engine="python")
C12_dropped = C12.drop(columns=["Index", "gtot", "Unc", "tau", "g", "+/-", "ef", "L", "S", "O", "Fsym", "id", "src", "Ecalc"])
print(C12_dropped)

c12_b = C12_dropped[C12_dropped['State'] == 'b(3SIGMA-g)']
# Extract features (v, J) and target (E)
X = c12_b[["v", "J"]].values
Y = c12_b["Energy"].values
print("NOW USING THE LINEAR FITTING")

true_values_b = [6434.27, 1470.45, 11.19, 1.49852, 0.01634, 0.00000622]
# True coefficients for Te, we, wexe, Be, ae and De for b3sigma-g (NIST)

# Split the data into training and testing sets
X_train, X_test, Y_train, Y_test = train_test_split(X, Y, test_size=0.20)

# Train a Random Forest model
rf_model = RandomForestRegressor(n_estimators=2000, random_state=42)
rf_model.fit(X_train, Y_train)

# Make predictions
y_pred_test = rf_model.predict(X_test)
y_pred_train = rf_model.predict(X_train)

# Plot the regression of the RF model
plt.figure(figsize=(8, 8))
plt.xlim(10000,12000)
plt.ylim(10000,12000)
plt.plot([0, 24000], [0, 24000], color='red', linestyle='--')
plt.plot(Y_train, y_pred_train,"o", label='Train set', alpha=0.7)
plt.plot(Y_test, y_pred_test,"o", label='Test set', alpha=0.7)
plt.xlabel('True Values', fontsize=16)
plt.ylabel('Predictions', fontsize=16)
plt.title('True Values vs Predictions', fontsize=16)
plt.show()

# Transform features for linear regression
X_transformed = np.column_stack([
    (X_test[:, 0] + 0.5),  # (v + 1/2)
    (X_test[:, 0] + 0.5) ** 2,  # (v + 1/2)^2
    (X_test[:, 1] * (X_test[:, 1] + 1)),  # J(J + 1)
    (X_test[:, 1] ** 2) * (X_test[:, 1] + 1) ** 2  # J^2(J + 1)^2
])

# Fit a linear regression model
linear_model = LinearRegression()
linear_model.fit(X_transformed, y_pred_test)
predicted_coefficients = linear_model.coef_

print(f"Predicted Coefficients:")
print(f"a1: {predicted_coefficients[0]}")
print(f"a2: {predicted_coefficients[1]}")
print(f"a3: {predicted_coefficients[2]}")
print(f"a4: {predicted_coefficients[3]}")
print(f"    ")

print(f"Difference in coefs /ratio")
print(f"a1: {(true_values_b[1] - predicted_coefficients[0]) / true_values_b[1]}")
print(f"a2: {(true_values_b[2] - np.abs(predicted_coefficients[1])) / true_values_b[2]}")
print(f"a3: {(true_values_b[3] - np.abs(predicted_coefficients[2])) / true_values_b[3]}")
print(f"a4: {(true_values_b[4] - np.abs(predicted_coefficients[3])) / true_values_b[4]}")


# Calculate the evaluation metrics of the performance of the model
mae = mean_absolute_error(Y_test, y_pred_test)
mse = mean_squared_error(Y_test, y_pred_test)
rmse = np.sqrt(mse)
r2 = r2_score(Y_test, y_pred_test)

print("Model Performance Metrics:")
print(f"Mean Absolute Error (MAE): {mae:.6f}")
print(f"Mean Squared Error (MSE): {mse:.6f}")
print(f"Root Mean Squared Error (RMSE): {rmse:.6f}")
print(f"R-squared (R²): {r2:.6f}")


# Visualize predictions of the linear fitting
plt.figure(figsize=(8, 8))
plt.xlim(0, 15000)
plt.ylim(0, 15000)
plt.plot([0, 15000], [0, 15000], color='red', linestyle='--', label="Ideal")
plt.plot(Y_test, y_pred_test,"o")
plt.xlabel('True Values', fontsize=16)
plt.ylabel('Predictions', fontsize=16)
plt.title('True Values vs Predictions', fontsize=16)
plt.legend()
plt.show()

##########################################
print("NOW USING THE POLYNOMIAL FITTING")
# Once a lineal regression has been done, let's compare the results with a polynomial fitting

degree = 4  # Select a degree for the polynomial

poly = PolynomialFeatures(degree=degree)
X_poly = poly.fit_transform(X_test)

# Fit the model
model = LinearRegression()
model.fit(X_poly, y_pred_test)
predicted_coefficients = model.coef_

# Calculate the molecular rovibrational constants
we=predicted_coefficients[1]
wexe=np.abs(predicted_coefficients[3])
Be=np.abs(predicted_coefficients[5])
ae=np.abs(predicted_coefficients[8])
De=np.abs(predicted_coefficients[14])

print(f"we: {we}, wexe: {wexe}, Be: {Be}, ae: {ae}, De: {De}, true value: {true_values_b}")
print(f"Difference in coefs /ratio")
print(f"we: {(true_values_b[1] - we)/true_values_b[1]}")
print(f"wexe: {(true_values_b[2] - wexe)/true_values_b[2]}")
print(f"BE: {(true_values_b[3] - Be)/true_values_b[3]}")
print(f"ae: {(true_values_b[4] - ae)/true_values_b[4]}")
print(f"De: {(true_values_b[5] - De)/true_values_b[5]}")