import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.kernel_ridge import KernelRidge
from sklearn.model_selection import train_test_split
from sklearn.metrics import mean_squared_error, r2_score, mean_absolute_error

# Load the heat capacity data and change the file path to where you have the file saved in your computer
cp_file = r'C:\Users\Usuario\Desktop\UAM\M2\Machine Learning\HOMEWORKS\pythonProject\12C2__8states.cp.txt'
columns_cp = ["Temperature", "Cp"]
cp_data = pd.read_csv(cp_file, sep=r"\s+", names=columns_cp, skiprows=1, engine='python')
print(cp_data)  # Ensure the data is being read properly

# Prepare the data
X_cp = cp_data["Temperature"].values.reshape(-1, 1)
y_cp = cp_data["Cp"].values

# Split the data into training and testing sets
X_train_cp, X_test_cp, y_train_cp, y_test_cp = train_test_split(X_cp, y_cp, test_size=0.2, random_state=42)


# Define Kernel Ridge Regression models
krr_cp = KernelRidge(kernel="rbf", alpha=1e-2, gamma=1e-2)  # Heat capacity


# Train the models
krr_cp.fit(X_train_cp, y_train_cp)


# Predict heat capacity and partition function
y_pred_cp = krr_cp.predict(X_test_cp)


# Evaluate the models
mse_cp = mean_squared_error(y_test_cp, y_pred_cp)
r2_cp = r2_score(y_test_cp, y_pred_cp)
mae_cp = mean_absolute_error(y_test_cp, y_pred_cp)
print(f"Heat Capacity - MSE: {mse_cp:.6f}, R²: {r2_cp:.6f}, MAE: {mae_cp:.6f}, RMSE:{np.sqrt(mse_cp):.6f}")

# Generate smooth predictions for visualization
X_smooth = np.linspace(X_cp.min(), X_cp.max(), 500).reshape(-1, 1)
y_smooth_cp = krr_cp.predict(X_smooth)


# Plot results for heat capacity
plt.figure(figsize=(10, 6))
plt.plot(X_cp, y_cp, "r.", markersize=8, label="Heat Capacity Data")
plt.plot(X_smooth, y_smooth_cp, "b-", label="Heat Capacity Prediction")
plt.xlabel("Temperature (K)", fontsize=16)
plt.ylabel("Heat Capacity (J/K)", fontsize=16)
plt.title("Kernel Ridge Regression - Heat Capacity", fontsize=16)
plt.legend()
plt.grid()
plt.show()
