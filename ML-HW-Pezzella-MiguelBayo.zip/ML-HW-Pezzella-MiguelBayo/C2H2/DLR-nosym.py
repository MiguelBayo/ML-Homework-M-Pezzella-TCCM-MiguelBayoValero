import tensorflow as tf
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from keras.callbacks import EarlyStopping
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import pandas as pd
import numpy as np
from scipy.stats import pearsonr
import matplotlib.pyplot as plt
import scipy


l1 = 512   # Number of units in the first hidden layer
l2 = 256  # Number of units in the second hidden layer
size = 0.2
dropout = 0.2
l2norm = 0.0002
rate = 0.0005
epoch = 100
wn2h = 8065.54  # conversion factor 1eV = 8065.54 cm-1

# Load the data and change the file path to where you have the file located in your computer
file_path = r'C:\Users\Usuario\Desktop\UAM\M2\Machine Learning\HOMEWORKS\pythonProject\C2H2_energylevels_2019-03-20.txt'
columns = ["v1", "v2", "v3", "v4", "l4", "v5", "l5", "k", "J", "ef", "op", "Energy", "Unc", "NumTrans", "u/g", "Sym"]
c2h2 = pd.read_csv(file_path, sep=r"\s+", names=columns, skiprows=1)
c2h2.drop("ef", axis=1)
c2h2.drop("op", axis=1)
c2h2.drop("u/g", axis=1)
c2h2.drop("Sym", axis=1)

# Filter out rows with any "-1" in vibrational or rotational states
columns_to_check = ["v1", "v2", "v3", "v4", "l4", "v5", "l5", "k", "J"]
filtered_data = c2h2[~c2h2[columns_to_check].isin([-1]).any(axis=1)]

# Define inputs (X), target (Y), and uncertainty (U)
X = filtered_data[["v1", "v2", "v3", "v4", "l4", "v5", "l5", "k", "J"]].values
Y = filtered_data["Energy"].values
U = filtered_data["Unc"].values

Y = Y/wn2h
U = U/wn2h
# Normalize uncertainty values to avoid division by zero
U[U == 0] = 1e-10

# Split the data into training, validation, and test sets
X_train, X_tmp, Y_train, Y_tmp, U_train, U_tmp = train_test_split(X, Y, U, test_size=0.2)
X_valid, X_test, Y_valid, Y_test, U_valid, U_test = train_test_split(X_tmp, Y_tmp, U_tmp, test_size=0.5)

# Normalize the input data
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_valid_scaled = scaler.transform(X_valid)
X_test_scaled = scaler.transform(X_test)


# Build the model
model = tf.keras.Sequential([
    tf.keras.layers.Dense(l1, activation='relu', kernel_regularizer=tf.keras.regularizers.l2(l2norm)),
    tf.keras.layers.Dropout(dropout),
    tf.keras.layers.Dense(l2, activation='relu', kernel_regularizer=tf.keras.regularizers.l2(l2norm)),
    tf.keras.layers.Dense(1, activation='linear')  # Output layer for regression
])

# Compile the model
learning_rate = rate
adam_optimizer = tf.keras.optimizers.Adam(learning_rate=learning_rate)
model.compile(optimizer=adam_optimizer, loss='mean_squared_error')

# Early stopping to prevent overfitting
early_stopping = EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)
print("Intra-op parallelism threads: ", tf.config.threading.get_intra_op_parallelism_threads())
print("Inter-op parallelism threads: ", tf.config.threading.get_inter_op_parallelism_threads())

# Train the model
history = model.fit(
    X_train_scaled, Y_train,
    epochs=100,
    validation_data=(X_valid_scaled, Y_valid),
    callbacks=[early_stopping],
    verbose=1
)

# Make predictions on the test set
predictions = model.predict(X_test_scaled)

# Evaluate the model
overall_mse = mean_squared_error(Y_test, predictions)
overall_mae = mean_absolute_error(Y_test, predictions)
r2 = r2_score(Y_test, predictions)

print(f"Overall MSE: {overall_mse:.6f}")
print(f"Overall RMSE: {np.sqrt(overall_mse):.6f}")
print(f"Overall MAE: {overall_mae:.6f}")
print(f"R-squared (R²): {r2:.6f}")

# Compute Pearson correlation
correlation, p_value = pearsonr(Y_test, predictions.ravel())
print(f"Pearson Correlation: {correlation:.4f}")
print(f"P-value: {p_value:.4e}")


###########################################

loss = history.history['loss']
val_loss = history.history['val_loss']
steps = range(1, len(loss) + 1)

# Plot the loss
plt.figure(figsize=(10, 6))
plt.yscale("log")

plt.plot(steps, loss, label='Training Loss')
plt.plot(steps, val_loss, label='Validation Loss')
plt.title('Loss Function as Number of Steps', fontsize = 16)
plt.xlabel('Training Steps (Epochs)', fontsize = 16)
plt.ylabel('Loss', fontsize = 16)
plt.legend()
plt.grid()
plt.show()


#################################
c2h2.drop("ef", axis=1)
c2h2.drop("op", axis=1)
c2h2.drop("u/g", axis=1)
c2h2.drop("Sym", axis=1)
c2h2

#############################

errors = Y_test -predictions.flatten()
plt.hist(errors,bins=100)
plt.title('Histogram of Prediction Errors', fontsize = 16)
plt.xlabel('Error (eV)', fontsize = 16)
plt.ylabel('Frequency', fontsize = 16)
plt.show()
# Plotting the error distribution
plt.figure(figsize=(10, 6))

# Calculate and display statistics
mean_error = np.mean(errors)
std_error = np.std(errors)

# Print statistics
print(f'Mean Error: {mean_error:.2f}')
print(f'Standard Deviation of Error: {std_error:.2f}')
print(f'Skewness of Error: {scipy.stats.skew(errors):.2f}')
print(f'Kurtosis of Error: {scipy.stats.kurtosis(errors):.2f}')

##########################################

# Save the DataFrame with predictions to a CSV file. Change the path to where you want to save the data or
# comment it out if you do not want to save the data into a file

output_file_path = r'C:\Users\Usuario\Desktop\UAM\M2\Machine Learning\HOMEWORKS\pythonProject\c2h2_predictions-DLR.txt'

with open(output_file_path, 'w') as f:
    # Write the evaluation metrics
    f.write(f"Evaluation metrics:\n")
    f.write("\n")
    f.write(f"Overall MSE: {overall_mse:.6f}\n")
    f.write(f"Overall RMSE: {np.sqrt(overall_mse):.6f}\n")
    f.write(f"Overall MAE: {overall_mae:.6f}\n")
    f.write(f"R²: {r2:.6f}\n")
    f.write(f"Pearson Correlation: {correlation:.4f}\n")
    f.write(f"P-value: {p_value:.4e}\n")
    f.write("\n")
    f.write("Distribution Measurements:\n")
    f.write("\n")
    f.write(f'Mean Error: {mean_error:.2f}\n')
    f.write(f'Standard Deviation of Error: {std_error:.2f}\n')
    f.write(f'Skewness of Error: {scipy.stats.skew(errors):.2f}\n')
    f.write(f'Kurtosis of Error: {scipy.stats.kurtosis(errors):.2f}\n')
    f.write("\n")


print(f"Results saved to {output_file_path}")
