import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from sklearn.ensemble import RandomForestRegressor
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from scipy.stats import pearsonr, skew, kurtosis
from sklearn.cluster import KMeans
import seaborn as sns
# Constants
wn2h = 8065.54  # Conversion factor 1eV = 8065.54 cm^-1
# Recall to change the file path to where you have the file located in your computer
file_path = r'C:\Users\Usuario\Desktop\UAM\M2\Machine Learning\HOMEWORKS\pythonProject\C2H2_energylevels_2019-03-20.txt'

# Load the data
columns = ["v1", "v2", "v3", "v4", "l4", "v5", "l5", "k", "J", "ef", "op", "Energy", "Unc", "NumTrans", "u/g", "Sym"]
c2h2 = pd.read_csv(file_path, sep=r"\s+", names=columns, skiprows=1)

# Handle case sensitivity
c2h2["ef"] = c2h2["ef"].str.lower()
c2h2["op"] = c2h2["op"].str.lower()
c2h2["u/g"] = c2h2["u/g"].str.lower()
c2h2["Sym"] = c2h2["Sym"].str.lower()

# Map rotational quantum numbers to numeric values
mapping_ef = {"e": 0, "f": 1}
mapping_op = {"ortho": 0, "para": 1}
mapping_ug = {"u": 0, "g": 1}
mapping_sym = {
    "sigma_g_plus": 0, "pi_g": 1, "pi_u": 2, "delta_g": 3, "sigma_u_plus": 4,
    "sigma_u_minus": 5, "delta_u": 6, "phi_g": 7, "phi_u": 8, "sigma_g_minus": 9, "gamma_u": 10
}

c2h2["ef"] = c2h2["ef"].map(mapping_ef)
c2h2["op"] = c2h2["op"].map(mapping_op)
c2h2["u/g"] = c2h2["u/g"].map(mapping_ug)
c2h2["Sym"] = c2h2["Sym"].map(mapping_sym)

# Drop rows with missing mappings
c2h2 = c2h2.dropna(subset=["ef", "op", "u/g", "Sym"])

# Filter out rows with any "-1" in vibrational or rotational states
columns_to_check = ["v1", "v2", "v3", "v4", "l4", "v5", "l5", "k", "J"]
filtered_data = c2h2[~c2h2[columns_to_check].isin([-1]).any(axis=1)]

if filtered_data.empty:
    raise ValueError("Filtered dataset is empty. Check your filtering conditions.")

# Define inputs (X), target (Y), and uncertainty (U)
X = filtered_data[["v1", "v2", "v3", "v4", "l4", "v5", "l5", "k", "J", "ef", "op", "u/g", "Sym"]].values
Y = filtered_data["Energy"].values / wn2h  # Change of units. Energy is now in eV
U = filtered_data["Unc"].values / wn2h  # Change of units

# Avoid division by zero in uncertainty
U[U == 0] = 1e-10

# Split the data into training, validation, and test sets
X_train, X_tmp, Y_train, Y_tmp, U_train, U_tmp = train_test_split(X, Y, U, test_size=0.2, random_state=42)
X_valid, X_test, Y_valid, Y_test, U_valid, U_test = train_test_split(X_tmp, Y_tmp, U_tmp, test_size=0.5, random_state=42)

# Normalize the input data
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_valid_scaled = scaler.transform(X_valid)
X_test_scaled = scaler.transform(X_test)

# Train the Random Forest model
rf_model = RandomForestRegressor(n_estimators=1000, random_state=42)
rf_model.fit(X_train_scaled, Y_train)

# Make predictions
test_predictions = rf_model.predict(X_test_scaled)

# Evaluate the model
mse_test = mean_squared_error(Y_test, test_predictions)
mae_test = mean_absolute_error(Y_test, test_predictions)
r2_test = r2_score(Y_test, test_predictions)
rmse_test = np.sqrt(mse_test)

# Print evaluation metrics
print(f"Test Set Metrics:")
print(f"MSE: {mse_test:.6f}")
print(f"RMSE: {rmse_test:.6f}")
print(f"MAE: {mae_test:.6f}")
print(f"R^2 Score: {r2_test:.6f}")

# Compute Pearson correlation
correlation, p_value = pearsonr(Y_test, test_predictions)
print(f"Pearson Correlation: {correlation:.4f}")
print(f"P-value: {p_value:.4e}")

# Visualize predictions
plt.figure(figsize=(8, 8))
plt.xlim(0, max(Y_test))
plt.ylim(0, max(Y_test))
plt.plot([0, max(Y_test)], [0, max(Y_test)], color='red', linestyle='--', label='Ideal')
plt.scatter(Y_test, test_predictions, alpha=0.6, label='Predictions')
plt.xlabel('True Values', fontsize=16)
plt.ylabel('Predictions', fontsize=16)
plt.title('True Values vs Predictions', fontsize=16)
plt.legend()
plt.grid()
plt.show()

# Histogram of Prediction Errors
errors = Y_test - test_predictions
plt.hist(errors, bins=100, alpha=0.75, color='blue')
plt.title('Histogram of Prediction Errors', fontsize=16)
plt.xlabel('Error (eV)', fontsize=16)
plt.ylabel('Frequency', fontsize=16)
plt.show()

# Print error distribution statistics
print(f"Mean Error: {errors.mean():.6f}")
print(f"Standard Deviation of Error: {errors.std():.6f}")
print(f"Skewness of Error: {skew(errors):.6f}")
print(f"Kurtosis of Error: {kurtosis(errors):.6f}")

######################################


# K-means Clustering Based on Symmetries

# Constants
num_clusters = 11  # Adjust the number of clusters as needed

# Prepare the data for clustering
features = filtered_data[["v1", "v2", "v3", "v4", "l4", "v5", "l5", "k", "J", "Sym"]]
reverse_symmetry_mapping = {v: k for k, v in mapping_sym.items()}


# Decode the symmetry labels for plotting
filtered_data["Sym_Decoded"] = filtered_data["Sym"].map(reverse_symmetry_mapping)

scaler = StandardScaler()
features_scaled = scaler.fit_transform(features)

# Apply K-means clustering
kmeans = KMeans(n_clusters=num_clusters)
kmeans.fit(features_scaled)
labels = kmeans.labels_
filtered_data["Cluster"] = labels


# Analyze the clustering
print("Cluster Centers:\n", kmeans.cluster_centers_)
print("Cluster labels for each point:", kmeans.labels_)


# Visualize clusters
sns.scatterplot(
    x=filtered_data["Sym_Decoded"],  # Example: Symmetry
    y=filtered_data["Energy"] / wn2h,  # Normalize energy for plotting
    hue=filtered_data["Cluster"],
    palette="tab10"
)
plt.title("K-Means Clustering", fontsize=16)
plt.xlabel("Symmetry", fontsize=16)
plt.ylabel("Energy (eV)", fontsize=16)
plt.xticks(rotation=-90)
plt.show()

# Save the data with cluster labels. Change the path to where you want to save the data or comment it out if you do not
# # want to save the data into a file
output_file_path = r'C:\Users\Usuario\Desktop\UAM\M2\Machine Learning\HOMEWORKS\pythonProject\c2h2_clusters-rf.csv'
filtered_data.to_csv(output_file_path, index=False)
