import tensorflow as tf
from sklearn.model_selection import train_test_split
from sklearn.preprocessing import StandardScaler
from keras.callbacks import EarlyStopping
from sklearn.metrics import mean_squared_error, mean_absolute_error, r2_score
import pandas as pd
import numpy as np
from scipy.stats import pearsonr
import matplotlib.pyplot as plt
from sklearn.cluster import KMeans
import seaborn as sns
import scipy

# Define constants
l1 = 512  # Number of units in the first hidden layer
l2 = 256  # Number of units in the second hidden layer
size = 0.2
dropout = 0.2
l2norm = 0.0002
rate = 0.0005
epoch = 100
wn2h = 8065.54  # conversion factor from cm-1 to eV.

# Load the data and change the file path to where you have the file located in your computer
file_path = r'C:\Users\Usuario\Desktop\UAM\M2\Machine Learning\HOMEWORKS\pythonProject\C2H2_energylevels_2019-03-20.txt'
columns = ["v1", "v2", "v3", "v4", "l4", "v5", "l5", "k", "J", "ef", "op", "Energy", "Unc", "NumTrans", "u/g", "Sym"]
c2h2 = pd.read_csv(file_path, sep=r"\s+", names=columns, skiprows=1)


print("Unique values in ef:", c2h2["ef"].unique())
print("Unique values in op:", c2h2["op"].unique())
print("Unique values in u/g:", c2h2["u/g"].unique())
print("Unique values in Sym:", c2h2["Sym"].unique())


# Handle case sensitivity
c2h2["ef"] = c2h2["ef"].str.lower()
c2h2["op"] = c2h2["op"].str.lower()
c2h2["u/g"] = c2h2["u/g"].str.lower()
c2h2["Sym"] = c2h2["Sym"].str.lower()


# Assign numeric values to quantum numbers
mapping_ef = {"e": 0, "f": 1}  # Assign 0 to "e" and 1 to "f"
mapping_op = {"ortho": 0, "para": 1}  # Assign 0 to "o" and 1 to "p"
mapping_ug = {"u": 0, "g": 1}  # Assign 0 to "u" and 1 to "g"
mapping_sym = {"sigma_g_plus": 0, "pi_g": 1, "pi_u": 2, "delta_g": 3, "sigma_u_plus": 4, "sigma_u_minus": 5, "delta_u": 6, "phi_g": 7, "phi_u": 8, "sigma_g_minus": 9, "gamma_u": 10}

# Apply mappings
c2h2["ef"] = c2h2["ef"].map(mapping_ef)
c2h2["op"] = c2h2["op"].map(mapping_op)
c2h2["u/g"] = c2h2["u/g"].map(mapping_ug)
c2h2["Sym"] = c2h2["Sym"].map(mapping_sym)


# debug step to verify mappings, if the dataset contains unexpected values or missing data.
if c2h2[["ef", "op", "u/g", "Sym"]].isna().any().any():
    print("Rows with invalid quantum numbers:")
    print(c2h2[c2h2[["ef", "op", "u/g", "Sym"]].isna().any(axis=1)])
    raise ValueError("Unexpected values in quantum number mappings!")


# Drop rows with invalid or missing mappings
c2h2 = c2h2.dropna(subset=["ef", "op", "u/g", "Sym"])

# Filter out rows with any "-1" in vibrational or rotational states
columns_to_check = ["v1", "v2", "v3", "v4", "l4", "v5", "l5", "k", "J"]
filtered_data = c2h2[~c2h2[columns_to_check].isin([-1]).any(axis=1)]

if filtered_data.empty:
    raise ValueError("Filtered dataset is empty. Check your filtering conditions.")


if filtered_data.shape[0] == 0:
    raise ValueError("No valid data rows after filtering. Check filtering criteria.")


# Define inputs (X), target (Y), and uncertainty (U)
X = filtered_data[["v1", "v2", "v3", "v4", "l4", "v5", "l5", "k", "J", "ef", "op", "u/g", "Sym"]].values
Y = filtered_data["Energy"].values
U = filtered_data["Unc"].values

# Convert energy and uncertainty to eV
Y = Y / wn2h
U = U / wn2h
U[U == 0] = 1e-10

# Split the data into training, validation, and test sets
X_train, X_tmp, Y_train, Y_tmp, U_train, U_tmp = train_test_split(X, Y, U, test_size=0.2)
X_valid, X_test, Y_valid, Y_test, U_valid, U_test = train_test_split(X_tmp, Y_tmp, U_tmp, test_size=0.5)

# Normalize the input data
scaler = StandardScaler()
X_train_scaled = scaler.fit_transform(X_train)
X_valid_scaled = scaler.transform(X_valid)
X_test_scaled = scaler.transform(X_test)

# Build the model
model = tf.keras.Sequential([
    tf.keras.layers.Dense(l1, activation='relu', kernel_regularizer=tf.keras.regularizers.l2(l2norm)),
    tf.keras.layers.Dropout(dropout),
    tf.keras.layers.Dense(l2, activation='relu', kernel_regularizer=tf.keras.regularizers.l2(l2norm)),
    tf.keras.layers.Dense(1, activation='linear')  # Output layer for regression
])

# Compile the model
learning_rate = rate
adam_optimizer = tf.keras.optimizers.Adam(learning_rate=learning_rate)
model.compile(optimizer=adam_optimizer, loss='mean_squared_error')
# Compile the model

# Early stopping to prevent overfitting
early_stopping = EarlyStopping(monitor='val_loss', patience=10, restore_best_weights=True)

# Train the model
history = model.fit(
    X_train_scaled, Y_train,
    epochs=epoch,
    validation_data=(X_valid_scaled, Y_valid),
    callbacks=[early_stopping],
    verbose=1
)

# Make predictions on the test set
predictions = model.predict(X_test_scaled)

# Evaluate the model
overall_mse = mean_squared_error(Y_test, predictions)
overall_mae = mean_absolute_error(Y_test, predictions)
r2 = r2_score(Y_test, predictions)
print(f"Overall MSE: {overall_mse:.6f}")
print(f"Overall RMSE: {np.sqrt(overall_mse):.6f}")
print(f"Overall MAE: {overall_mae:.6f}")
print(f"R-squared (R²): {r2:.6f}")
# Compute Pearson correlation
correlation, p_value = pearsonr(Y_test, predictions.ravel())
print(f"Pearson Correlation: {correlation:.4f}")
print(f"P-value: {p_value:.4e}")

# Plot the loss during training
plt.plot(history.history['loss'], label='Training Loss')
plt.plot(history.history['val_loss'], label='Validation Loss')
plt.yscale('log')
plt.xlabel('Epochs', fontsize=16)
plt.ylabel('Loss', fontsize=16)
plt.legend()
plt.title('Training and Validation Loss', fontsize=16)
plt.show()

# Plot histogram of errors
errors = Y_test -predictions.flatten()
plt.hist(errors,bins=100)
plt.title('Histogram of Prediction Errors', fontsize=16)
plt.xlabel('Error (eV)', fontsize=16)
plt.ylabel('Frequency', fontsize=16)
plt.show()
# Plotting the error distribution
plt.figure(figsize=(10, 6))

# Calculate and display statistics
mean_error = np.mean(errors)
std_error = np.std(errors)

# Print statistics
print(f'Mean Error: {mean_error:.2f}')
print(f'Standard Deviation of Error: {std_error:.2f}')
print(f'Skewness of Error: {scipy.stats.skew(errors):.2f}')
print(f'Kurtosis of Error: {scipy.stats.kurtosis(errors):.2f}')


# Save the predictions to a file. Change the path to where you want to save the data or comment it out if you do not
# want to save the data into a file
output_file_path = r'C:\Users\Usuario\Desktop\UAM\M2\Machine Learning\HOMEWORKS\pythonProject\c2h2_predictions-symmetry-dlr.txt'

test_indices = filtered_data.index[len(X_train) + len(X_valid):]
filtered_data_test = filtered_data.loc[test_indices].copy()
filtered_data_test.loc[:, "Predicted_Energy"] = predictions.ravel()
filtered_data_test.to_csv(output_file_path, index=False)


###########################################

# K-means Clustering Based on Symmetries

# Constants
num_clusters = 11  # Adjust the number of clusters as needed

# Prepare the data for clustering
features = filtered_data[["v1", "v2", "v3", "v4", "l4", "v5", "l5", "k", "J", "Sym"]].copy()
reverse_symmetry_mapping = {v: k for k, v in mapping_sym.items()}


# Decode the symmetry labels for plotting
filtered_data = filtered_data.copy()
filtered_data.loc[:, "Sym_Decoded"] = filtered_data["Sym"].map(reverse_symmetry_mapping)


scaler = StandardScaler()
features_scaled = scaler.fit_transform(features)

# Apply K-means clustering
kmeans = KMeans(n_clusters=num_clusters)
kmeans.fit(features_scaled)

labels = kmeans.labels_
filtered_data["Cluster"] = labels


# Analyze the clustering
print("Cluster Centers:\n", kmeans.cluster_centers_)
print("Cluster labels for each point:", kmeans.labels_)

# Visualize clusters
sns.scatterplot(
    x=filtered_data["Sym_Decoded"],  # Example: rotational quantum number
    y=filtered_data["Energy"] / wn2h,  # Normalize energy for plotting
    hue=filtered_data["Cluster"],
    palette="tab10"
)
plt.title("K-Means Clustering", fontsize=16)
plt.xlabel("Symmetry", fontsize=16)
plt.ylabel("Energy (eV)", fontsize=16)
plt.xticks(rotation=-90)
plt.show()

# Save the data with cluster labels. Change the path to where you want to save the data or comment it out if you do not
# want to save the data into a file
output_file_path = r'C:\Users\Usuario\Desktop\UAM\M2\Machine Learning\HOMEWORKS\pythonProject\c2h2_clusters-dlr.csv'
filtered_data.to_csv(output_file_path, index=False)
